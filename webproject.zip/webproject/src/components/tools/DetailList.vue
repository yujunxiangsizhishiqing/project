<script>
/* WARNING: 兼容老引入，请勿继续使用 */
import DescriptionList from '@/components/DescriptionList'
export default DescriptionList
</script>
