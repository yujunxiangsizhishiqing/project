import DescriptionList from './DescriptionList'
export default DescriptionList
