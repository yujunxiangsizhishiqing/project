<template>
  <div>
    <h1>临客费项</h1>
  </div>
</template>

<script>
export default {}
</script>

<style>
</style>
